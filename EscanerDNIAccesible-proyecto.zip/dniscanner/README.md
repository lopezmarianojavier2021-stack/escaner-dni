# Escáner DNI Accesible

App para Android que escanea el frente y el dorso del DNI. La cámara reconoce sola qué lado le estás mostrando (usa detección de rostro para el frente y el código de barras PDF417 para el dorso) y avisa todo por voz: qué lado detectó, cuándo saca la foto, y cuándo terminó. Al final podés guardar las dos fotos en la galería o compartirlas.

Todo el procesamiento de imagen pasa en el propio celular (con ML Kit), no se manda ninguna foto a internet.

## Por qué este proyecto no viene con el .apk ya compilado

El entorno donde armé el proyecto no tiene acceso a los repositorios de Google/Android necesarios para compilar (Google Maven, Maven Central), así que no puedo generar el instalable desde acá. Para solucionarlo, el proyecto ya incluye un workflow de GitHub Actions (`.github/workflows/build-apk.yml`) que compila el APK automáticamente en los servidores de GitHub, gratis, sin que tengas que instalar Android Studio ni nada pesado en tu notebook.

## Cómo conseguir el .apk

1. Si no tenés cuenta en GitHub, creá una gratis en github.com (el sitio es bastante accesible con NVDA).
2. Creá un repositorio nuevo (puede ser privado). No hace falta tildar ninguna opción especial.
3. Subí el contenido de esta carpeta al repositorio. Se puede hacer desde la web: en la página del repositorio buscá la opción "Add file" y después "Upload files", y arrastrá o seleccioná todos los archivos y carpetas de este proyecto (incluida la carpeta oculta `.github`).
4. Confirmá la subida (botón "Commit changes"). Apenas se suba el código, GitHub arranca a compilar solo, porque el workflow ya está incluido.
5. Andá a la pestaña "Actions" del repositorio. Vas a ver una ejecución en curso llamada "Compilar APK". Tarda entre 3 y 6 minutos.
6. Cuando termine (estado "success"), entrá a esa ejecución y bajá hasta la sección "Artifacts". Ahí vas a encontrar un archivo llamado "EscanerDNI-apk" para descargar. Es un .zip que contiene el .apk adentro.
7. Descargá ese .zip, descomprimilo, y vas a tener el archivo `app-debug.apk`.
8. Pasá ese archivo a tu celular (por ejemplo mandándotelo por correo, subiéndolo a Google Drive, o descargándolo directamente desde el celular si hiciste estos pasos desde ahí).
9. En el celular, abrí el archivo .apk para instalarlo. La primera vez Android va a pedir que habilites "Instalar apps desconocidas" para la aplicación que estés usando para abrirlo (por ejemplo, el navegador o el gestor de archivos). Se habilita una sola vez.

Si en algún paso preferís que yo haga la subida a GitHub por vos, contame y armamos otra forma: creás un repositorio vacío, generás un token de acceso personal (Settings, Developer settings, Personal access tokens) y me lo pasás; con eso puedo subir el proyecto yo mismo y avisarte cuando esté listo para descargar.

## Cómo funciona el reconocimiento de frente y dorso

- El DNI argentino (tarjeta) tiene, en el dorso, un código de barras PDF417. La app lo busca constantemente con la cámara; si lo encuentra, sabe que está viendo el dorso.
- Si no hay código de barras pero la cámara detecta un rostro, asume que está viendo el frente (donde está la foto).
- Cuando detecta un lado de forma estable durante menos de un segundo, avisa por voz y saca la foto sola, sin que haga falta tocar ningún botón.
- Si ya capturó un lado y volvés a mostrárselo, te avisa que ese lado ya está guardado y te pide el que falta.
- Si no encuentra el documento, cada tanto te sugiere acercarlo más a la cámara y buscar un lugar con buena luz.

## Estructura del proyecto

- `app/src/main/java/com/blynd/dniscanner/MainActivity.kt`: pantalla de bienvenida y permiso de cámara.
- `app/src/main/java/com/blynd/dniscanner/ScanActivity.kt`: cámara, detección automática y captura.
- `app/src/main/java/com/blynd/dniscanner/ReviewActivity.kt`: revisión, guardado en galería y compartir.
- `app/src/main/java/com/blynd/dniscanner/SpeechHelper.kt`: manejo de los avisos por voz (texto a voz).
- `.github/workflows/build-apk.yml`: compilación automática en GitHub.

## Posibles mejoras a futuro

- Agregar un botón manual de captura como respaldo si la detección automática falla en algún celular.
- Sumar reconocimiento de tarjetas de débito/crédito (mismo problema de frente/dorso).
- Firmar la app con una clave propia para poder subirla a Google Play más adelante (el .apk actual es de tipo "debug", pensado para instalar directo en el celular).

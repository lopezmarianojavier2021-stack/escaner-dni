package com.blynd.dniscanner

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.blynd.dniscanner.databinding.ActivityAcercaDeBinding

/**
 * Pantalla "Acerca de": para qué sirve la app, cómo se usa, y qué versión
 * es la que está instalada (útil para saber si ya se actualizó, o para
 * avisar el número de versión si hay que reportar un problema).
 */
class AcercaDeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAcercaDeBinding
    private lateinit var voz: SpeechHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAcercaDeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val textoVersion = getString(
            R.string.acerca_de_version,
            BuildConfig.VERSION_NAME,
            BuildConfig.VERSION_CODE
        )
        binding.txtVersion.text = textoVersion

        voz = SpeechHelper(this) {
            val paraLeer = listOf(
                getString(R.string.acerca_de_titulo),
                textoVersion,
                getString(R.string.acerca_de_descripcion),
                getString(R.string.acerca_de_instrucciones)
            ).joinToString(". ")
            voz.decirEnCola(paraLeer)
        }

        binding.txtTituloAcercaDe.requestFocus()
    }

    override fun onDestroy() {
        voz.liberar()
        super.onDestroy()
    }
}

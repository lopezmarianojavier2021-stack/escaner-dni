package com.blynd.dniscanner

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Envoltorio simple sobre el motor de Text-to-Speech de Android.
 *
 * Se usa para avisar por voz lo que va pasando durante el escaneo
 * (frente detectado, dorso detectado, foto guardada, etc.) sin depender
 * de que TalkBack esté activado: así la app también sirve para gente que
 * usa otro lector de pantalla, o ninguno.
 */
class SpeechHelper(context: Context, private val onReady: (() -> Unit)? = null) {

    private var tts: TextToSpeech? = null
    private var listo = false
    private val hiloPrincipal = Handler(Looper.getMainLooper())

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val engine = tts
                if (engine != null) {
                    val resultado = engine.setLanguage(Locale("es", "AR"))
                    if (resultado == TextToSpeech.LANG_MISSING_DATA ||
                        resultado == TextToSpeech.LANG_NOT_SUPPORTED
                    ) {
                        engine.setLanguage(Locale("es", "ES"))
                    }
                }
                listo = true
                onReady?.invoke()
            }
        }
    }

    /**
     * Interrumpe cualquier anuncio anterior y dice el texto nuevo de inmediato.
     * Se usa para avisos urgentes (frente detectado, dorso detectado).
     */
    fun decirYa(texto: String, idUtterance: String = texto.hashCode().toString()) {
        if (!listo) return
        tts?.stop()
        tts?.speak(texto, TextToSpeech.QUEUE_FLUSH, null, idUtterance)
    }

    /** Encola el texto sin interrumpir lo que se está diciendo. */
    fun decirEnCola(texto: String, idUtterance: String = texto.hashCode().toString()) {
        if (!listo) return
        tts?.speak(texto, TextToSpeech.QUEUE_ADD, null, idUtterance)
    }

    /**
     * Dice el texto y ejecuta [callback] cuando termina de hablar.
     *
     * Los callbacks del motor de TTS no llegan en el hilo principal, así que
     * [callback] se despacha siempre con un Handler al hilo principal: quien
     * llama puede tocar la cámara o la interfaz sin preocuparse por el hilo.
     */
    fun decirYLuego(texto: String, callback: () -> Unit) {
        if (!listo) {
            hiloPrincipal.post(callback)
            return
        }
        val idUtterance = "u_" + System.currentTimeMillis()
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                if (utteranceId == idUtterance) hiloPrincipal.post(callback)
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                if (utteranceId == idUtterance) hiloPrincipal.post(callback)
            }
        })
        tts?.stop()
        tts?.speak(texto, TextToSpeech.QUEUE_FLUSH, null, idUtterance)
    }

    fun estaHablando(): Boolean = tts?.isSpeaking == true

    fun liberar() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}

package com.blynd.dniscanner

import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import androidx.appcompat.app.AppCompatActivity
import com.blynd.dniscanner.databinding.ActivityReviewBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ReviewActivity : AppCompatActivity() {

    private lateinit var binding: ActivityReviewBinding
    private lateinit var voz: SpeechHelper

    private var uriFrente: Uri? = null
    private var uriDorso: Uri? = null

    companion object {
        const val EXTRA_URI_FRENTE = "extra_uri_frente"
        const val EXTRA_URI_DORSO = "extra_uri_dorso"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReviewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        uriFrente = intent.getStringExtra(EXTRA_URI_FRENTE)?.let { Uri.parse(it) }
        uriDorso = intent.getStringExtra(EXTRA_URI_DORSO)?.let { Uri.parse(it) }

        binding.imgFrente.setImageURI(uriFrente)
        binding.imgDorso.setImageURI(uriDorso)

        voz = SpeechHelper(this) {
            voz.decirEnCola(getString(R.string.tts_review_listo))
        }

        binding.btnGuardar.setOnClickListener { guardarEnGaleria() }
        binding.btnCompartir.setOnClickListener { compartir() }
        binding.btnReescanear.setOnClickListener {
            startActivity(Intent(this, ScanActivity::class.java))
            finish()
        }
    }

    private fun guardarEnGaleria() {
        val frente = uriFrente
        val dorso = uriDorso
        if (frente == null || dorso == null) return

        try {
            copiarAGaleria(frente, "dni_frente")
            copiarAGaleria(dorso, "dni_dorso")
            voz.decirYa(getString(R.string.tts_guardado_exitoso))
        } catch (e: Exception) {
            voz.decirYa(getString(R.string.tts_guardado_error))
        }
    }

    private fun copiarAGaleria(origen: Uri, nombreBase: String) {
        val marcaTiempo = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val nombreArchivo = "${nombreBase}_$marcaTiempo.jpg"

        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, nombreArchivo)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(
                    MediaStore.Images.Media.RELATIVE_PATH,
                    Environment.DIRECTORY_PICTURES + "/EscanerDNI"
                )
            }
        }

        val destino = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("No se pudo crear el archivo destino")

        contentResolver.openOutputStream(destino).use { salida ->
            contentResolver.openInputStream(origen).use { entrada ->
                if (entrada == null || salida == null) throw IllegalStateException("No se pudo copiar la imagen")
                entrada.copyTo(salida)
            }
        }
    }

    private fun compartir() {
        val frente = uriFrente
        val dorso = uriDorso
        if (frente == null || dorso == null) return

        val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "image/jpeg"
            putParcelableArrayListExtra(
                Intent.EXTRA_STREAM,
                arrayListOf(frente, dorso)
            )
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, getString(R.string.compartir_titulo)))
    }

    override fun onDestroy() {
        voz.liberar()
        super.onDestroy()
    }
}

package com.blynd.dniscanner

import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import androidx.appcompat.app.AppCompatActivity
import com.blynd.dniscanner.databinding.ActivityReviewBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Pantalla que se muestra después de CADA foto capturada (frente o dorso),
 * de forma independiente: no hace falta tener las dos para guardar o
 * compartir esta.
 */
class ReviewActivity : AppCompatActivity() {

    private lateinit var binding: ActivityReviewBinding
    private lateinit var voz: SpeechHelper

    private var uriFoto: Uri? = null
    private var lado: String = "FRENTE"
    private var ambosCompletos: Boolean = false

    companion object {
        const val EXTRA_URI = "extra_uri"
        const val EXTRA_LADO = "extra_lado"
        const val EXTRA_AMBOS_COMPLETOS = "extra_ambos_completos"
        const val EXTRA_TERMINAR = "extra_terminar"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReviewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        uriFoto = intent.getStringExtra(EXTRA_URI)?.let { Uri.parse(it) }
        lado = intent.getStringExtra(EXTRA_LADO) ?: "FRENTE"
        ambosCompletos = intent.getBooleanExtra(EXTRA_AMBOS_COMPLETOS, false)

        binding.imgFoto.setImageURI(uriFoto)
        binding.imgFoto.contentDescription = if (lado == "FRENTE")
            getString(R.string.review_frente_desc)
        else
            getString(R.string.review_dorso_desc)

        binding.txtTituloReview.text = if (lado == "FRENTE")
            getString(R.string.review_titulo_frente)
        else
            getString(R.string.review_titulo_dorso)

        configurarBotonContinuar()

        voz = SpeechHelper(this) {
            val mensaje = when {
                ambosCompletos -> getString(R.string.tts_review_ambos_listo)
                lado == "FRENTE" -> getString(R.string.tts_review_frente_listo)
                else -> getString(R.string.tts_review_dorso_listo)
            }
            voz.decirEnCola(mensaje)
        }

        binding.btnGuardar.setOnClickListener { guardarEnGaleria() }
        binding.btnCompartir.setOnClickListener { compartir() }
        binding.btnDescribir.setOnClickListener { describirImagen() }
        binding.btnContinuar.setOnClickListener { continuarOFinalizar() }
    }

    private fun configurarBotonContinuar() {
        if (ambosCompletos) {
            binding.btnContinuar.text = getString(R.string.boton_finalizar)
            binding.btnContinuar.contentDescription = getString(R.string.boton_finalizar)
        } else if (lado == "FRENTE") {
            binding.btnContinuar.text = getString(R.string.boton_continuar_dorso)
            binding.btnContinuar.contentDescription = getString(R.string.boton_continuar_dorso)
        } else {
            binding.btnContinuar.text = getString(R.string.boton_continuar_frente)
            binding.btnContinuar.contentDescription = getString(R.string.boton_continuar_frente)
        }
    }

    private fun describirImagen() {
        val mensaje = if (lado == "FRENTE")
            getString(R.string.tts_describir_frente)
        else
            getString(R.string.tts_describir_dorso)
        voz.decirYa(mensaje)
    }

    private fun continuarOFinalizar() {
        val resultado = Intent()
        resultado.putExtra(EXTRA_TERMINAR, ambosCompletos)
        setResult(RESULT_OK, resultado)
        finish()
    }

    private fun guardarEnGaleria() {
        val foto = uriFoto ?: return
        try {
            val nombreBase = if (lado == "FRENTE") "dni_frente" else "dni_dorso"
            copiarAGaleria(foto, nombreBase)
            voz.decirYa(getString(R.string.tts_guardado_exitoso))
        } catch (e: Exception) {
            voz.decirYa(getString(R.string.tts_guardado_error))
        }
    }

    private fun copiarAGaleria(origen: Uri, nombreBase: String) {
        val marcaTiempo = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val nombreArchivo = "${nombreBase}_$marcaTiempo.jpg"

        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, nombreArchivo)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(
                    MediaStore.Images.Media.RELATIVE_PATH,
                    Environment.DIRECTORY_PICTURES + "/EscanerDNI"
                )
            }
        }

        val destino = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("No se pudo crear el archivo destino")

        contentResolver.openOutputStream(destino).use { salida ->
            contentResolver.openInputStream(origen).use { entrada ->
                if (entrada == null || salida == null) throw IllegalStateException("No se pudo copiar la imagen")
                entrada.copyTo(salida)
            }
        }
    }

    private fun compartir() {
        val foto = uriFoto ?: return
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, foto)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, getString(R.string.compartir_titulo)))
    }

    override fun onDestroy() {
        voz.liberar()
        super.onDestroy()
    }
}

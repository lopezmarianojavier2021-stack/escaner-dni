package com.blynd.dniscanner

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.blynd.dniscanner.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var voz: SpeechHelper

    private val pedirPermisoCamara =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { concedido ->
            if (concedido) {
                irAEscanear()
            } else {
                mostrarPermisoDenegado()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        voz = SpeechHelper(this) {
            voz.decirEnCola(getString(R.string.tts_bienvenida))
        }

        binding.txtTitulo.requestFocus()

        binding.btnIniciar.setOnClickListener {
            verificarPermisoYContinuar()
        }
    }

    private fun verificarPermisoYContinuar() {
        val yaTienePermiso = ContextCompat.checkSelfPermission(
            this, Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

        if (yaTienePermiso) {
            irAEscanear()
        } else {
            voz.decirYLuego(getString(R.string.tts_permiso_solicitar)) {
                pedirPermisoCamara.launch(Manifest.permission.CAMERA)
            }
        }
    }

    private fun irAEscanear() {
        startActivity(Intent(this, ScanActivity::class.java))
    }

    private fun mostrarPermisoDenegado() {
        voz.decirYa(getString(R.string.tts_permiso_denegado))
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.app_name))
            .setMessage(getString(R.string.permiso_camara_necesario))
            .setPositiveButton(getString(R.string.boton_abrir_configuracion)) { _, _ ->
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                intent.data = Uri.fromParts("package", packageName, null)
                startActivity(intent)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    override fun onDestroy() {
        voz.liberar()
        super.onDestroy()
    }
}

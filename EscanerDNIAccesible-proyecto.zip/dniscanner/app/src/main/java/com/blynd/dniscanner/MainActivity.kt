package com.blynd.dniscanner

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.blynd.dniscanner.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var voz: SpeechHelper

    private val pedirPermisoCamara =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { concedido ->
            if (concedido) {
                irAEscanear()
            } else {
                mostrarPermisoDenegado()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        voz = SpeechHelper(this) {
            voz.decirEnCola(getString(R.string.tts_bienvenida))
        }

        binding.txtTitulo.requestFocus()

        binding.btnIniciar.setOnClickListener {
            verificarPermisoYContinuar()
        }

        binding.btnBuscarActualizaciones.setOnClickListener {
            buscarActualizacionesManual()
        }

        binding.btnAjustes.setOnClickListener {
            startActivity(Intent(this, AjustesActivity::class.java))
        }

        binding.btnAcercaDe.setOnClickListener {
            startActivity(Intent(this, AcercaDeActivity::class.java))
        }

        ActualizadorApp.verificarEnSegundoPlano(this) {
            mostrarDialogoActualizacion()
        }

        revisarNovedadesDeLaVersion()
    }

    private fun buscarActualizacionesManual() {
        voz.decirYa(getString(R.string.tts_buscando_actualizaciones))
        ActualizadorApp.verificarManual(this) { encontrada, error ->
            when {
                error -> voz.decirYa(getString(R.string.tts_actualizacion_error_conexion))
                encontrada -> {
                    voz.decirYa(getString(R.string.tts_actualizacion_encontrada_manual))
                    ActualizadorApp.descargarEInstalar(this, voz)
                }
                else -> voz.decirYa(getString(R.string.tts_ya_actualizado))
            }
        }
    }

    /**
     * Si esta ejecución de la app corresponde a una versión más nueva que
     * la última vez que se abrió (es decir, se acaba de instalar una
     * actualización), muestra qué cambió. No se muestra en la primera
     * instalación, porque ahí no hay "novedades" que contar todavía.
     */
    private fun revisarNovedadesDeLaVersion() {
        val prefs = getSharedPreferences("actualizador_prefs", MODE_PRIVATE)
        val versionActual = BuildConfig.VERSION_CODE
        val versionVista = prefs.getInt("version_vista_novedades", -1)
        if (versionVista == versionActual) return

        prefs.edit().putInt("version_vista_novedades", versionActual).apply()
        if (versionVista == -1) return // primera instalación: nada que contar

        voz.decirYa(getString(R.string.tts_novedades_intro))
        voz.decirEnCola(getString(R.string.novedades_texto))
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.novedades_titulo))
            .setMessage(getString(R.string.novedades_texto))
            .setPositiveButton(android.R.string.ok, null)
            .show()
    }

    private fun mostrarDialogoActualizacion() {
        voz.decirYa(getString(R.string.tts_actualizacion_disponible))
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.actualizacion_titulo))
            .setMessage(getString(R.string.actualizacion_mensaje))
            .setPositiveButton(getString(R.string.boton_actualizar_ahora)) { _, _ ->
                voz.decirYa(getString(R.string.tts_descargando_actualizacion))
                ActualizadorApp.descargarEInstalar(this, voz)
            }
            .setNegativeButton(getString(R.string.boton_ahora_no), null)
            .show()
    }

    private fun verificarPermisoYContinuar() {
        val yaTienePermiso = ContextCompat.checkSelfPermission(
            this, Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

        if (yaTienePermiso) {
            irAEscanear()
        } else {
            voz.decirYLuego(getString(R.string.tts_permiso_solicitar)) {
                pedirPermisoCamara.launch(Manifest.permission.CAMERA)
            }
        }
    }

    private fun irAEscanear() {
        startActivity(Intent(this, ScanActivity::class.java))
    }

    private fun mostrarPermisoDenegado() {
        voz.decirYa(getString(R.string.tts_permiso_denegado))
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.app_name))
            .setMessage(getString(R.string.permiso_camara_necesario))
            .setPositiveButton(getString(R.string.boton_abrir_configuracion)) { _, _ ->
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                intent.data = Uri.fromParts("package", packageName, null)
                startActivity(intent)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    override fun onDestroy() {
        voz.liberar()
        super.onDestroy()
    }
}

package com.blynd.dniscanner

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.blynd.dniscanner.databinding.ActivityScanBinding
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.io.File

private enum class Lado { NINGUNO, FRENTE, DORSO }

class ScanActivity : AppCompatActivity() {

    private lateinit var binding: ActivityScanBinding
    private lateinit var voz: SpeechHelper

    private lateinit var imageCapture: ImageCapture

    private val barcodeScanner by lazy {
        BarcodeScanning.getClient(
            BarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_PDF417)
                .build()
        )
    }

    private val faceDetector by lazy {
        FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .build()
        )
    }

    // --- Estado del escaneo ---
    private var ladoActualDetectado: Lado = Lado.NINGUNO
    private var ladoDetectadoDesde: Long = 0L
    private var capturando = false
    private var frenteListo = false
    private var dorsoListo = false
    private var uriFrente: Uri? = null
    private var uriDorso: Uri? = null
    private var ultimoAvisoRepetido = 0L

    companion object {
        private const val TIEMPO_ESTABLE_MS = 700L
        private const val COOLDOWN_AVISO_MS = 4000L
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScanBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            finish()
            return
        }

        voz = SpeechHelper(this) {
            voz.decirEnCola(getString(R.string.tts_scan_instrucciones_iniciales))
        }

        iniciarCamara()
    }

    private fun iniciarCamara() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(binding.previewView.surfaceProvider)
            }

            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()

            val imageAnalysis = androidx.camera.core.ImageAnalysis.Builder()
                .setBackpressureStrategy(androidx.camera.core.ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            imageAnalysis.setAnalyzer(ContextCompat.getMainExecutor(this)) { imageProxy ->
                analizarFrame(imageProxy)
            }

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    this,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    preview,
                    imageCapture,
                    imageAnalysis
                )
            } catch (e: Exception) {
                actualizarEstado("No se pudo iniciar la cámara.")
                voz.decirYa("No se pudo iniciar la cámara. Volvé a intentarlo.")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analizarFrame(imageProxy: ImageProxy) {
        if (capturando) {
            imageProxy.close()
            return
        }
        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            return
        }
        val inputImage = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)

        barcodeScanner.process(inputImage)
            .addOnSuccessListener(this) { barcodes ->
                if (barcodes.isNotEmpty()) {
                    manejarDeteccion(Lado.DORSO)
                    imageProxy.close()
                } else {
                    faceDetector.process(inputImage)
                        .addOnSuccessListener(this) { faces ->
                            manejarDeteccion(if (faces.isNotEmpty()) Lado.FRENTE else Lado.NINGUNO)
                        }
                        .addOnFailureListener { }
                        .addOnCompleteListener { imageProxy.close() }
                }
            }
            .addOnFailureListener {
                imageProxy.close()
            }
    }

    private fun manejarDeteccion(lado: Lado) {
        val ahora = System.currentTimeMillis()

        if (lado != ladoActualDetectado) {
            ladoActualDetectado = lado
            ladoDetectadoDesde = ahora
            return
        }

        when (lado) {
            Lado.NINGUNO -> {
                if (ahora - ultimoAvisoRepetido > COOLDOWN_AVISO_MS) {
                    ultimoAvisoRepetido = ahora
                    actualizarEstado(getString(R.string.scan_estado_buscando))
                    if (ahora - ladoDetectadoDesde > 6000L) {
                        voz.decirYa(getString(R.string.tts_no_detecta_documento))
                    }
                }
            }

            Lado.FRENTE -> {
                if (frenteListo) {
                    if (ahora - ultimoAvisoRepetido > COOLDOWN_AVISO_MS) {
                        ultimoAvisoRepetido = ahora
                        actualizarEstado(getString(R.string.scan_estado_frente_listo))
                        voz.decirYa(getString(R.string.tts_frente_ya_capturado))
                    }
                    return
                }
                actualizarEstado(getString(R.string.scan_estado_frente_detectado))
                if (ahora - ladoDetectadoDesde >= TIEMPO_ESTABLE_MS) {
                    dispararCaptura(Lado.FRENTE)
                }
            }

            Lado.DORSO -> {
                if (dorsoListo) {
                    if (ahora - ultimoAvisoRepetido > COOLDOWN_AVISO_MS) {
                        ultimoAvisoRepetido = ahora
                        actualizarEstado(getString(R.string.scan_estado_dorso_listo))
                        voz.decirYa(getString(R.string.tts_dorso_ya_capturado))
                    }
                    return
                }
                actualizarEstado(getString(R.string.scan_estado_dorso_detectado))
                if (ahora - ladoDetectadoDesde >= TIEMPO_ESTABLE_MS) {
                    dispararCaptura(Lado.DORSO)
                }
            }
        }
    }

    private fun dispararCaptura(lado: Lado) {
        capturando = true
        val mensaje = if (lado == Lado.FRENTE)
            getString(R.string.tts_frente_detectado_capturando)
        else
            getString(R.string.tts_dorso_detectado_capturando)

        voz.decirYLuego(mensaje) {
            tomarFoto(lado)
        }
    }

    private fun tomarFoto(lado: Lado) {
        val carpeta = File(cacheDir, "dni_cache").apply { mkdirs() }
        val archivo = File(carpeta, if (lado == Lado.FRENTE) "frente.jpg" else "dorso.jpg")
        val opciones = ImageCapture.OutputFileOptions.Builder(archivo).build()

        imageCapture.takePicture(
            opciones,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    val uri = FileProvider.getUriForFile(
                        this@ScanActivity,
                        "$packageName.fileprovider",
                        archivo
                    )
                    vibrar()
                    if (lado == Lado.FRENTE) {
                        frenteListo = true
                        uriFrente = uri
                    } else {
                        dorsoListo = true
                        uriDorso = uri
                    }
                    continuarLuegoDeCaptura(lado)
                }

                override fun onError(exception: ImageCaptureException) {
                    capturando = false
                    voz.decirYa("No se pudo sacar la foto, probemos de nuevo.")
                }
            }
        )
    }

    private fun continuarLuegoDeCaptura(lado: Lado) {
        ladoActualDetectado = Lado.NINGUNO
        ultimoAvisoRepetido = 0L

        if (frenteListo && dorsoListo) {
            actualizarEstado(getString(R.string.scan_estado_frente_listo))
            voz.decirYLuego(getString(R.string.tts_ambos_lados_completos)) {
                irARevision()
            }
        } else {
            val mensaje = if (lado == Lado.FRENTE)
                getString(R.string.tts_frente_guardado)
            else
                getString(R.string.tts_dorso_guardado)

            voz.decirYLuego(mensaje) {
                capturando = false
            }
        }
    }

    private fun irARevision() {
        val intent = Intent(this, ReviewActivity::class.java)
        intent.putExtra(ReviewActivity.EXTRA_URI_FRENTE, uriFrente.toString())
        intent.putExtra(ReviewActivity.EXTRA_URI_DORSO, uriDorso.toString())
        startActivity(intent)
        finish()
    }

    private fun actualizarEstado(texto: String) {
        binding.txtEstado.text = texto
    }

    private fun vibrar() {
        val vibrator: Vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager
            manager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as Vibrator
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }

    override fun onDestroy() {
        voz.liberar()
        barcodeScanner.close()
        faceDetector.close()
        super.onDestroy()
    }
}

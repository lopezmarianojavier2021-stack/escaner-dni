package com.blynd.dniscanner

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Size
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.blynd.dniscanner.databinding.ActivityScanBinding
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.io.File

private enum class Lado { NINGUNO, FRENTE, DORSO }

class ScanActivity : AppCompatActivity() {

    private lateinit var binding: ActivityScanBinding
    private lateinit var voz: SpeechHelper

    private lateinit var imageCapture: ImageCapture
    private var camera: Camera? = null
    private val hiloPrincipal = Handler(Looper.getMainLooper())
    private val refocoPeriodico = object : Runnable {
        override fun run() {
            if (!capturando) enfocarCentro()
            hiloPrincipal.postDelayed(this, 2500L)
        }
    }

    private val barcodeScanner by lazy {
        // El DNI argentino "clásico" trae un código PDF417 en el dorso; el
        // DNI nuevo (tarjeta de policarbonato, desde 2026) lo reemplaza por
        // un código QR. Si en Ajustes se eligió un tipo puntual, buscamos
        // solo ese código (más rápido y con menos falsos positivos); si no,
        // aceptamos cualquier formato para reconocer los dos.
        val prefsAjustes = getSharedPreferences(AjustesActivity.PREFS, MODE_PRIVATE)
        val tipoDocumento = prefsAjustes.getString(
            AjustesActivity.KEY_TIPO_DOCUMENTO,
            AjustesActivity.TIPO_AUTO
        )
        val formato = when (tipoDocumento) {
            AjustesActivity.TIPO_NUEVO -> Barcode.FORMAT_QR_CODE
            AjustesActivity.TIPO_VIEJO -> Barcode.FORMAT_PDF417
            else -> Barcode.FORMAT_ALL_FORMATS
        }
        BarcodeScanning.getClient(
            BarcodeScannerOptions.Builder()
                .setBarcodeFormats(formato)
                .build()
        )
    }

    private val faceDetector by lazy {
        FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                // Las caras de una foto de DNI ocupan poco lugar en el encuadre
                // comparadas con una selfie: bajamos el tamaño mínimo detectable.
                .setMinFaceSize(0.05f)
                .build()
        )
    }

    // --- Estado del escaneo ---
    private var ladoActualDetectado: Lado = Lado.NINGUNO
    private var ladoDetectadoDesde: Long = 0L
    private var capturando = false
    private var frenteListo = false
    private var dorsoListo = false
    private var ultimoAvisoRepetido = 0L

    private val revisionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { resultado ->
        val terminar = resultado.data?.getBooleanExtra(ReviewActivity.EXTRA_TERMINAR, false) ?: false
        if (terminar) {
            voz.decirYa(getString(R.string.tts_ambos_lados_completos))
            finish()
        } else {
            ladoActualDetectado = Lado.NINGUNO
            ultimoAvisoRepetido = 0L
            capturando = false
            val mensaje = when {
                !frenteListo -> getString(R.string.tts_frente_guardado)
                !dorsoListo -> getString(R.string.tts_dorso_guardado)
                else -> getString(R.string.tts_scan_instrucciones_iniciales)
            }
            voz.decirEnCola(mensaje)
        }
    }

    companion object {
        private const val TIEMPO_ESTABLE_MS = 600L
        private const val COOLDOWN_AVISO_MS = 4000L
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScanBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            finish()
            return
        }

        voz = SpeechHelper(this) {
            voz.decirEnCola(getString(R.string.tts_scan_instrucciones_iniciales))
        }

        iniciarCamara()
    }

    private fun iniciarCamara() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(binding.previewView.surfaceProvider)
            }

            imageCapture = ImageCapture.Builder()
                // Prioriza nitidez sobre velocidad: importante para que se
                // lean bien los datos impresos en el documento.
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .build()

            // Resolución más alta para el análisis: las barras finas de un
            // código de barras necesitan bastante detalle para poder
            // leerse, más que una cara. 1920x1080 sigue siendo manejable en
            // tiempo real en la mayoría de los celulares.
            val resolutionSelector = ResolutionSelector.Builder()
                .setResolutionStrategy(
                    ResolutionStrategy(Size(1920, 1080), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
                )
                .build()

            val imageAnalysis = ImageAnalysis.Builder()
                .setResolutionSelector(resolutionSelector)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            imageAnalysis.setAnalyzer(ContextCompat.getMainExecutor(this)) { imageProxy ->
                analizarFrame(imageProxy)
            }

            try {
                cameraProvider.unbindAll()
                camera = cameraProvider.bindToLifecycle(
                    this,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    preview,
                    imageCapture,
                    imageAnalysis
                )
                // Foco continuo al centro del encuadre, re-disparado cada
                // pocos segundos: en distancias cortas (documento pegado a la
                // cámara) el enfoque automático del sistema a veces no
                // reacciona solo, así que lo forzamos nosotros.
                binding.previewView.post { enfocarCentro() }
                hiloPrincipal.postDelayed(refocoPeriodico, 2500L)
            } catch (e: Exception) {
                actualizarEstado("No se pudo iniciar la cámara.")
                voz.decirYa("No se pudo iniciar la cámara. Volvé a intentarlo.")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun enfocarCentro() {
        val cam = camera ?: return
        if (binding.previewView.width == 0 || binding.previewView.height == 0) return
        val factory = binding.previewView.meteringPointFactory
        val punto = factory.createPoint(
            binding.previewView.width / 2f,
            binding.previewView.height / 2f
        )
        val accion = FocusMeteringAction.Builder(
            punto,
            FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
        ).disableAutoCancel().build()
        cam.cameraControl.startFocusAndMetering(accion)
    }

    private fun analizarFrame(imageProxy: ImageProxy) {
        if (capturando) {
            imageProxy.close()
            return
        }
        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            return
        }
        val inputImage = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)

        barcodeScanner.process(inputImage)
            .addOnSuccessListener(this) { barcodes ->
                if (barcodes.isNotEmpty()) {
                    manejarDeteccion(Lado.DORSO)
                    imageProxy.close()
                } else {
                    faceDetector.process(inputImage)
                        .addOnSuccessListener(this) { faces ->
                            manejarDeteccion(if (faces.isNotEmpty()) Lado.FRENTE else Lado.NINGUNO)
                        }
                        .addOnFailureListener { }
                        .addOnCompleteListener { imageProxy.close() }
                }
            }
            .addOnFailureListener {
                imageProxy.close()
            }
    }

    private fun manejarDeteccion(lado: Lado) {
        val ahora = System.currentTimeMillis()

        if (lado != ladoActualDetectado) {
            ladoActualDetectado = lado
            ladoDetectadoDesde = ahora
            return
        }

        when (lado) {
            Lado.NINGUNO -> {
                if (ahora - ultimoAvisoRepetido > COOLDOWN_AVISO_MS) {
                    ultimoAvisoRepetido = ahora
                    actualizarEstado(getString(R.string.scan_estado_buscando))
                    if (ahora - ladoDetectadoDesde > 6000L) {
                        voz.decirYa(getString(R.string.tts_no_detecta_documento))
                    }
                }
            }

            Lado.FRENTE -> {
                if (frenteListo) {
                    if (ahora - ultimoAvisoRepetido > COOLDOWN_AVISO_MS) {
                        ultimoAvisoRepetido = ahora
                        actualizarEstado(getString(R.string.scan_estado_frente_listo))
                        voz.decirYa(getString(R.string.tts_frente_ya_capturado))
                    }
                    return
                }
                actualizarEstado(getString(R.string.scan_estado_frente_detectado))
                if (ahora - ladoDetectadoDesde >= TIEMPO_ESTABLE_MS) {
                    dispararCaptura(Lado.FRENTE)
                }
            }

            Lado.DORSO -> {
                if (dorsoListo) {
                    if (ahora - ultimoAvisoRepetido > COOLDOWN_AVISO_MS) {
                        ultimoAvisoRepetido = ahora
                        actualizarEstado(getString(R.string.scan_estado_dorso_listo))
                        voz.decirYa(getString(R.string.tts_dorso_ya_capturado))
                    }
                    return
                }
                actualizarEstado(getString(R.string.scan_estado_dorso_detectado))
                if (ahora - ladoDetectadoDesde >= TIEMPO_ESTABLE_MS) {
                    dispararCaptura(Lado.DORSO)
                }
            }
        }
    }

    private fun dispararCaptura(lado: Lado) {
        capturando = true
        var yaContinuo = false

        // No sacamos la foto hasta confirmar que el enfoque quedó fijo en
        // el documento: antes se podía disparar la captura mientras la
        // cámara todavía estaba ajustando el foco, y la foto salía borrosa.
        val continuarConLaFoto = {
            if (!yaContinuo) {
                yaContinuo = true
                val mensaje = if (lado == Lado.FRENTE)
                    getString(R.string.tts_frente_detectado_capturando)
                else
                    getString(R.string.tts_dorso_detectado_capturando)
                voz.decirYLuego(mensaje) {
                    tomarFoto(lado)
                }
            }
        }

        val cam = camera
        if (cam != null && binding.previewView.width > 0 && binding.previewView.height > 0) {
            val factory = binding.previewView.meteringPointFactory
            val punto = factory.createPoint(
                binding.previewView.width / 2f,
                binding.previewView.height / 2f
            )
            val accion = FocusMeteringAction.Builder(
                punto,
                FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
            ).build()
            try {
                val futuroEnfoque = cam.cameraControl.startFocusAndMetering(accion)
                futuroEnfoque.addListener(
                    { continuarConLaFoto() },
                    ContextCompat.getMainExecutor(this)
                )
            } catch (e: Exception) {
                continuarConLaFoto()
            }
            // Salvavidas: si por algún motivo el enfoque nunca avisa que
            // terminó, igual sacamos la foto para no dejar la app trabada.
            hiloPrincipal.postDelayed({ continuarConLaFoto() }, 700L)
        } else {
            continuarConLaFoto()
        }
    }

    private fun tomarFoto(lado: Lado) {
        val carpeta = File(cacheDir, "dni_cache").apply { mkdirs() }
        val archivo = File(carpeta, if (lado == Lado.FRENTE) "frente.jpg" else "dorso.jpg")
        val opciones = ImageCapture.OutputFileOptions.Builder(archivo).build()

        imageCapture.takePicture(
            opciones,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    val uri = FileProvider.getUriForFile(
                        this@ScanActivity,
                        "$packageName.fileprovider",
                        archivo
                    )
                    vibrar()
                    if (lado == Lado.FRENTE) {
                        frenteListo = true
                    } else {
                        dorsoListo = true
                    }
                    irARevision(uri, lado)
                }

                override fun onError(exception: ImageCaptureException) {
                    capturando = false
                    voz.decirYa("No se pudo sacar la foto, probemos de nuevo.")
                }
            }
        )
    }

    private fun irARevision(uri: Uri, lado: Lado) {
        val intent = Intent(this, ReviewActivity::class.java)
        intent.putExtra(ReviewActivity.EXTRA_URI, uri.toString())
        intent.putExtra(ReviewActivity.EXTRA_LADO, if (lado == Lado.FRENTE) "FRENTE" else "DORSO")
        intent.putExtra(ReviewActivity.EXTRA_AMBOS_COMPLETOS, frenteListo && dorsoListo)
        revisionLauncher.launch(intent)
    }

    private fun actualizarEstado(texto: String) {
        binding.txtEstado.text = texto
    }

    private fun vibrar() {
        val vibrator: Vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager
            manager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as Vibrator
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }

    override fun onPause() {
        hiloPrincipal.removeCallbacks(refocoPeriodico)
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (::imageCapture.isInitialized) {
            hiloPrincipal.postDelayed(refocoPeriodico, 500L)
        }
    }

    override fun onDestroy() {
        hiloPrincipal.removeCallbacks(refocoPeriodico)
        voz.liberar()
        barcodeScanner.close()
        faceDetector.close()
        super.onDestroy()
    }
}

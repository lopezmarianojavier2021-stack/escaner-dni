package com.blynd.dniscanner

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Chequea si hay una versión más nueva del .apk publicada en GitHub, y si el
 * usuario acepta, la descarga y abre el instalador. No usa Google Play: la
 * app se compara contra el "release" fijo que arma la compilación automática.
 *
 * Cómo detecta si hay algo nuevo: GitHub guarda, para el archivo del
 * release, la fecha en que se subió y su tamaño. Guardamos esos dos datos la
 * primera vez que se revisa, y si cambian en una revisión posterior,
 * asumimos que se subió una versión nueva.
 */
object ActualizadorApp {

    private const val API_URL =
        "https://api.github.com/repos/lopezmarianojavier2021-stack/escaner-dni/releases/tags/ultima-version"
    private const val DOWNLOAD_URL =
        "https://github.com/lopezmarianojavier2021-stack/escaner-dni/releases/download/ultima-version/EscanerDNI.apk"
    private const val PREFS = "actualizador_prefs"
    private const val KEY_FIRMA = "ultima_firma_release"

    /**
     * Consulta la firma (fecha + tamaño) del instalable publicado
     * actualmente en GitHub. Devuelve null si no se pudo consultar.
     */
    private fun obtenerFirmaRemota(): String? {
        val conexion = URL(API_URL).openConnection() as HttpURLConnection
        conexion.setRequestProperty("Accept", "application/vnd.github+json")
        conexion.connectTimeout = 8000
        conexion.readTimeout = 8000

        val texto = conexion.inputStream.bufferedReader().use { it.readText() }
        val json = JSONObject(texto)
        val assets = json.optJSONArray("assets") ?: return null
        if (assets.length() == 0) return null
        val asset = assets.getJSONObject(0)
        return asset.optString("updated_at") + "_" + asset.optLong("size")
    }

    fun verificarEnSegundoPlano(context: Context, alEncontrarActualizacion: () -> Unit) {
        Thread {
            try {
                val firmaActual = obtenerFirmaRemota() ?: return@Thread
                val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                val firmaGuardada = prefs.getString(KEY_FIRMA, null)

                if (firmaGuardada == null) {
                    // Primera vez que la app chequea: guarda la referencia
                    // actual sin avisar (no es una actualización, es la
                    // versión que ya tiene instalada).
                    prefs.edit().putString(KEY_FIRMA, firmaActual).apply()
                    return@Thread
                }

                if (firmaGuardada != firmaActual) {
                    prefs.edit().putString(KEY_FIRMA, firmaActual).apply()
                    Handler(Looper.getMainLooper()).post { alEncontrarActualizacion() }
                }
            } catch (e: Exception) {
                // Sin conexión, o GitHub no responde: no interrumpimos al usuario.
            }
        }.start()
    }

    /**
     * Chequeo manual, disparado por el botón "Buscar actualizaciones".
     * A diferencia del chequeo en segundo plano, siempre avisa el
     * resultado (haya o no actualización, o haya error de conexión).
     */
    fun verificarManual(
        context: Context,
        alTerminar: (encontrada: Boolean, error: Boolean) -> Unit
    ) {
        Thread {
            try {
                val firmaActual = obtenerFirmaRemota()
                if (firmaActual == null) {
                    Handler(Looper.getMainLooper()).post { alTerminar(false, true) }
                    return@Thread
                }
                val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                val firmaGuardada = prefs.getString(KEY_FIRMA, null)
                val hayActualizacion = firmaGuardada != null && firmaGuardada != firmaActual
                prefs.edit().putString(KEY_FIRMA, firmaActual).apply()
                Handler(Looper.getMainLooper()).post { alTerminar(hayActualizacion, false) }
            } catch (e: Exception) {
                Handler(Looper.getMainLooper()).post { alTerminar(false, true) }
            }
        }.start()
    }

    fun descargarEInstalar(activity: Activity, voz: SpeechHelper) {
        Thread {
            try {
                val conexion = URL(DOWNLOAD_URL).openConnection() as HttpURLConnection
                conexion.instanceFollowRedirects = true
                conexion.connectTimeout = 15000
                conexion.readTimeout = 15000

                val carpeta = File(activity.cacheDir, "actualizaciones").apply { mkdirs() }
                val archivo = File(carpeta, "EscanerDNI_nuevo.apk")
                conexion.inputStream.use { entrada ->
                    FileOutputStream(archivo).use { salida -> entrada.copyTo(salida) }
                }

                Handler(Looper.getMainLooper()).post {
                    instalarApk(activity, archivo, voz)
                }
            } catch (e: Exception) {
                Handler(Looper.getMainLooper()).post {
                    voz.decirYa(activity.getString(R.string.tts_actualizacion_error))
                }
            }
        }.start()
    }

    private fun instalarApk(activity: Activity, archivo: File, voz: SpeechHelper) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            !activity.packageManager.canRequestPackageInstalls()
        ) {
            voz.decirYa(activity.getString(R.string.tts_actualizacion_permiso))
            val intent = Intent(
                android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:${activity.packageName}")
            )
            activity.startActivity(intent)
            return
        }

        val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", archivo)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        activity.startActivity(intent)
    }
}

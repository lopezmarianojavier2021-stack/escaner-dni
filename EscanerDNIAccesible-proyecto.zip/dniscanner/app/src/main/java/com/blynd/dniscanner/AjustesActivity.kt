package com.blynd.dniscanner

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.blynd.dniscanner.databinding.ActivityAjustesBinding

/**
 * Pantalla de ajustes. Por ahora solo permite elegir qué tipo de DNI se va
 * a escanear (nuevo, con código QR, o anterior, con código de barras), para
 * que ScanActivity pueda buscar puntualmente ese tipo de código en el
 * dorso en vez de probar con todos.
 */
class AjustesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAjustesBinding
    private lateinit var voz: SpeechHelper

    companion object {
        const val PREFS = "config_prefs"
        const val KEY_TIPO_DOCUMENTO = "tipo_documento"
        const val TIPO_AUTO = "AUTO"
        const val TIPO_NUEVO = "NUEVO"
        const val TIPO_VIEJO = "VIEJO"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAjustesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        voz = SpeechHelper(this) {
            voz.decirEnCola(getString(R.string.tts_ajustes_bienvenida))
        }

        binding.txtTituloAjustes.requestFocus()

        binding.btnTipoAuto.setOnClickListener { elegirTipo(TIPO_AUTO) }
        binding.btnTipoNuevo.setOnClickListener { elegirTipo(TIPO_NUEVO) }
        binding.btnTipoViejo.setOnClickListener { elegirTipo(TIPO_VIEJO) }

        actualizarBotones()
    }

    private fun elegirTipo(tipo: String) {
        getSharedPreferences(PREFS, MODE_PRIVATE)
            .edit()
            .putString(KEY_TIPO_DOCUMENTO, tipo)
            .apply()
        actualizarBotones()
        val mensaje = when (tipo) {
            TIPO_NUEVO -> getString(R.string.tts_tipo_nuevo_elegido)
            TIPO_VIEJO -> getString(R.string.tts_tipo_viejo_elegido)
            else -> getString(R.string.tts_tipo_auto_elegido)
        }
        voz.decirYa(mensaje)
    }

    private fun actualizarBotones() {
        val tipoActual = getSharedPreferences(PREFS, MODE_PRIVATE)
            .getString(KEY_TIPO_DOCUMENTO, TIPO_AUTO)
        val sufijo = getString(R.string.sufijo_seleccionado)

        binding.btnTipoAuto.text = getString(R.string.boton_tipo_auto) +
            if (tipoActual == TIPO_AUTO) sufijo else ""
        binding.btnTipoNuevo.text = getString(R.string.boton_tipo_nuevo) +
            if (tipoActual == TIPO_NUEVO) sufijo else ""
        binding.btnTipoViejo.text = getString(R.string.boton_tipo_viejo) +
            if (tipoActual == TIPO_VIEJO) sufijo else ""
    }

    override fun onDestroy() {
        voz.liberar()
        super.onDestroy()
    }
}

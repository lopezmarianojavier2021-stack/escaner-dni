# Reglas de ProGuard/R8 para compilaciones "release".
# Por ahora no se necesitan reglas especiales.
